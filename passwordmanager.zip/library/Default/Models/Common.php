<?php

class Default_Models_Common extends Zend_Db_Table_Abstract
{
	protected $_name;
	protected $_db;
	
	public function getWebsites($where = ''){
		$this->_db = $this->getAdapter();
		$this->_db->setFetchMode(PDO::FETCH_OBJ);
		$sql = "SELECT * FROM websites WHERE 1=1  ".$where;
		#echo $sql;# exit;
		$bind = array();
		$res = $this->_db->fetchAll($sql,$bind);
		return $res;
	}
	
	public function insertWebsites($info){		
		$this->_db = $this->getAdapter();
		$this->_db->setFetchMode(PDO::FETCH_OBJ);
		$sql = "INSERT into`websites`(websitename, websiteurl, savepassword, levelsms, levelemail, updated) values('".$info['websitename']."', '".addslashes($info['websiteurl'])."', '".$info['savepassword']."', '".$info['levelsms']."', '".$info['levelemail']."', '".date('Y-m-d H:i:s')."')";
		#echo "<br>".$sql; exit;
		$bind = array();
		$this->_db->query($sql,$bind);
		return $this->_db->lastInsertId();
	}
	
	public function updateWebsites($info){		
		$this->_db = $this->getAdapter();
		$this->_db->setFetchMode(PDO::FETCH_OBJ);
		$sql = "UPDATE `websites` SET `websitename` = '".$info['websitename']."', 
				`websitename` = '".$info['websitename']."', 
				`websiteurl` = '".addslashes($info['websiteurl'])."', 
				`savepassword` = '".$info['savepassword']."', 
				`levelsms` = '".$info['levelsms']."', 
				`levelemail` = '".$info['levelemail']."', 
				updated = '".date('Y-m-d H:i:s')."' 
				WHERE webid = '".$info['webid']."' ";
		#echo "<br>".$sql; exit;
		$bind = array();
		$this->_db->query($sql,$bind);
		return 1;
	}
	
	
	
	# peoples Related Functions - Start
	public function getAllPeoples($where = ''){
  	    $this->_db = $this->getAdapter();
	    $this->_db->setFetchMode(PDO::FETCH_OBJ);
		$sql = "SELECT a.* FROM adminusers as a 
				WHERE 1=1 AND a.userId != 1 ".$where;
		#echo $sql; exit;
		$bind = array();
		$res = $this->_db->fetchAll($sql,$bind);
		return $res;
	}
	
	public function insertPeoples($info){
		$this->_db = $this->getAdapter();
		$this->_db->setFetchMode(PDO::FETCH_OBJ);
		
		$sql = "INSERT INTO `adminusers` (`userName`, `userPassword`, `userType`, `userStatus`, orgpassword, firstName, mobile, emailAddress, lockpin,  created) VALUES ( '".strtolower($info['userName'])."', '".md5($info['userPassword'])."', 'U', '1', '".$info['userPassword']."', '".$info['fullname']."', '".$info['mobile']."', '".$info['email']."', '".$info['lockpin']."', '".date('Y-m-d H:i:s')."')";
		#echo $sql; exit;
		$bind = array();
		$this->_db->query($sql,$bind);
		$registerid = $this->_db->lastInsertId();
		return $registerid;
	}
	# peoples Related Functions - End
	
	public function insertSiteUser($info){		
		$this->_db = $this->getAdapter();
		$this->_db->setFetchMode(PDO::FETCH_OBJ);
		$sql = "INSERT into`savedsites`(userid, webid, username, password, savedat) values('".$info['userid']."', '".addslashes($info['webid'])."', '".$info['username']."', '".$info['password']."', '".date('Y-m-d H:i:s')."')";
		#echo "<br>".$sql; exit;
		$bind = array();
		$this->_db->query($sql,$bind);
		return $this->_db->lastInsertId();
	}	
	
	public function getSiteUser($where = ''){
		$this->_db = $this->getAdapter();
		$this->_db->setFetchMode(PDO::FETCH_OBJ);
		$sql = "SELECT ss.*, w.websitename  FROM savedsites as ss
		LEFT JOIN websites as w on ss.webid = w.webid
		WHERE 1=1  ".$where." ORDER by ss.savid desc";
		#echo $sql;# exit;
		$bind = array();
		$res = $this->_db->fetchAll($sql,$bind);
		return $res;
	}
	
	public function sendtestemail($emailinfo){
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL,"http://www.tripletechsoft.org/home/sendemailprojects");
		curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type: application/json; charset=utf-8;"));
		$data = json_encode ($emailinfo);
		curl_setopt($ch, CURLOPT_POST, $data);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLINFO_HEADER_OUT, true);

		//Actual Call to Server
		$server_output = curl_exec($ch);
		curl_close($ch);
		return $server_output;
	 }
	 
	 public function sendtestsms($info){
		
		$smsinfo = array(
							"username" => 'apartmentmaintenance',
							"password" => 'apartmentmaintenance',
							"smslist" => $info,
						);
		
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL,"http://www.tripletechsoft.org/sendsms/");
		curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type: application/json; charset=utf-8;"));
		$data = json_encode ($smsinfo);
		curl_setopt($ch, CURLOPT_POST, $data);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLINFO_HEADER_OUT, true);

		//Actual Call to Server
		$server_output = curl_exec($ch);
		curl_close($ch);
		return $server_output;
	 }
	
}
?>