<?php
class Default_Models_DbTable_Customers extends Zend_Db_Table_Abstract
{
    /** Table name */
    protected $_name    = 'customers';
}
