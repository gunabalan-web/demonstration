<?php
//Ig/Form/Element/TinyMce
class Default_Form_Element_FormTinyMce extends Zend_Form_Element_Textarea
{
	/**
	* Use formTextarea view helper by default
	* @var string
	*/
	public $helper = 'formTinyMce';
}