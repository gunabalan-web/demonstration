<?php
//Ig/Form/Element/TinyMce
class Default_Form_Element_TinyMce extends Zend_Form_Element_Textarea
{
	/**
	* Use formTextarea view helper by default
	* @var string
	*/
	public $helper = 'formTinyMce';
}