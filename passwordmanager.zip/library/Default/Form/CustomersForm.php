<?php
class Default_Form_CustomersForm extends Zend_Form
{
	public function __construct($options=array())
	{
		parent::__construct(array('decorators'=>array(
			'FormElements',
			'Fieldset',
			'Form',
		 ),'disableLoadDefaultDecorators' => true));

		$view = $this->getView();
		$this->setDisableLoadDefaultDecorators(true);
		$this->addPrefixPath('Default_Decorator_',APPLICATION_PATH . '/../library/Default/Decorator','decorator');
		$this->setMethod('post');
		
		if($view->profileaction == "add"){

		} else {
			$userid_element = new Zend_Form_Element_Hidden('cid',array(
						'value'	=> $view->row->cid));
			$userid_element->setDecorators(array('None'));
			$this->addElement($userid_element);
		}
		
		#--------------------------firstname-----------------------------------#
		$firstname_element  = new Zend_Form_Element_Text('firstname',array(
			'class'		=> 'form-control',
			'required'   => true,
			'value'   => $view->row->firstname,
			'placeholder'   => 'Firstname',
			'maxlength'   => '50',
			'filters'   => array('StringTrim','StripTags')
			));
		$firstname_element->setDecorators(array('CompositeNoLabel'));
		$this->addElement($firstname_element);
		 
		#--------------------------lastname-----------------------------------#
		$lastname_element  = new Zend_Form_Element_Text('lastname',array(
			'class'		=> 'form-control',
			'required'   => true,
			'value'   => $view->row->lastname,
			'placeholder'   => 'Lastname',
			'maxlength'   => '50',
			'filters'   => array('StringTrim','StripTags')
			));
		$lastname_element->setDecorators(array('CompositeNoLabel'));
		$this->addElement($lastname_element);
		 
		#--------------------------aadhar-----------------------------------#
		$aadhar_element  = new Zend_Form_Element_Text('aadhar',array(
			'class'		=> 'form-control',
			'required'   => true,
			'value'   => $view->row->aadhar,
			'placeholder'   => 'Aadhar',
			'maxlength'   => '12',
			'filters'   => array('StringTrim','StripTags')
			));
		$aadhar_element->setDecorators(array('CompositeNoLabel'));
		$this->addElement($aadhar_element);
		 
		#--------------------------email-----------------------------------#
		$email_element  = new Zend_Form_Element_Text('email',array(
			'class'		=> 'form-control',
			'required'   => true,
			'value'   => $view->row->email,
			'placeholder'   => 'Email',
			'maxlength'   => '50',
			'filters'   => array('StringTrim','StripTags')
			));
		$email_element->setDecorators(array('CompositeNoLabel'));
		$this->addElement($email_element);
		 
		#--------------------------mobile-----------------------------------#
		$mobile_element  = new Zend_Form_Element_Text('mobile',array(
			'class'		=> 'form-control',
			'required'   => true,
			'value'   => $view->row->mobile,
			'placeholder'   => 'Mobile',
			'maxlength'   => '15',
			'filters'   => array('StringTrim','StripTags')
			));
		$mobile_element->setAttrib('onkeyup', 'IsMobile(event);');
		$mobile_element->setDecorators(array('CompositeNoLabel'));
		$this->addElement($mobile_element);
		 
		#--------------------------address-----------------------------------#
		$address_element  = new Zend_Form_Element_Text('address',array(
			'class'		=> 'form-control',
			'required'   => false,
			'value'   => $view->row->address,
			'placeholder'   => 'Address',
			'filters'   => array('StringTrim','StripTags')
			));
		$address_element->setDecorators(array('CompositeNoLabel'));
		$this->addElement($address_element);
		 
		#--------------------------gender-----------------------------------#
		$gender = array(
						"" => "Select",
						"1" => "Male",
						"2" => "Female",
						"3" => "Other",
					);
		$gender_element  = new Zend_Form_Element_Select('gender',array(
			'class'		=> 'form-control',
			'required'   => true,
			'value'   => $view->row->gender,
			'filters'   => array('StringTrim','StripTags')
			));
		$gender_element->addMultiOptions($gender);
		$gender_element->setDecorators(array('CompositeNoLabel'));
		$this->addElement($gender_element);
		 
		#--------------------------dob-----------------------------------#
		$dob_element  = new Zend_Form_Element_Text('dob',array(
			'class'		=> 'form-control',
			'required'   => false,
			'value'   => $view->row->dob,
			'placeholder'   => 'Date of Birth',
			'filters'   => array('StringTrim','StripTags')
			));
		$dob_element->setDecorators(array('CompositeNoLabel'));
		$this->addElement($dob_element);
		
		#--------------------------status-----------------------------------#
		$status = array(
						"1" => "Active",
						"2" => "InActive",
					);
		$status_element  = new Zend_Form_Element_Select('status',array(
			'class'		=> 'form-control',
			'required'   => true,
			'value'   => $view->row->status,
			'filters'   => array('StringTrim','StripTags')
			));
		$status_element->addMultiOptions($status);
		$status_element->setDecorators(array('CompositeNoLabel'));
		$this->addElement($status_element);
	}
}
