<?php 
phpinfo();