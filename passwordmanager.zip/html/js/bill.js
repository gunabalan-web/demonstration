//productquantity update - start
$(document).on('keyup', '.productquantityser', function(){
	  var row_id = $(this).attr("id");
	  var res = row_id.split("_");
	 
	 if($(this).val() == ''){
		 qty = 0;
	 } else {
		 qty = $(this).val();
	 }
	 totamtq = parseFloat($('#productprice_'+res[1]).val()) * parseInt(qty);
	 $('#ttprice_txt_'+res[1]).html(totamtq.toFixed(2));	
	 $('#totalprice_'+res[1]).val(totamtq.toFixed(2));	
	 
	 //update price
	calculateprice();
 });
 
 //product autocomplete - start
 $(document).on('keydown', '.billinput', function(e){
	 if (e.which === 13) {
        var row_id = $(this).attr("id");
		var res = row_id.split("_");
		var nextid = parseInt(res[1]) + 1;
	   
		$('#productname_'+nextid).focus();
    }
 });
 
 $(document).on('keyup', '.productautosearch', function(){
		$(this).autocomplete({
               minLength: 2,
			   maxShowItems: 5,
               source: availableProducts, 
			   focus: function( event, ui ) {
                  //$(this).val( ui.item.label );
                     return false;
               },
               select: function( event, ui ) {
                  $( this ).val(ui.item.label);
				  
				  var row_id = $(this).attr("id");
				  var res = row_id.split("_");
				  
				  auprice = parseFloat(ui.item.value);
				  
				  
				  $('#billname_'+res[1]).html(ui.item.label);
				  $('#productcode_'+res[1]).val(ui.item.desc);
				  $('#productprice_'+res[1]).val(auprice.toFixed(2));
				  $('#productquantity_'+res[1]).val('1');
				  $('#totalprice_'+res[1]).val(auprice.toFixed(2));
				  
				  $('#price_txt_'+res[1]).html(auprice.toFixed(2));
				  $('#ttprice_txt_'+res[1]).html(auprice.toFixed(2));				  
					
				  $('.add_row').click();
				  
				  $('#productquantity_'+res[1]).focus();
				  $('#productquantity_'+res[1]).select();
				  //update price
					setTimeout(function(){ calculateprice(); }, 100);
                  return false;
               }
            })				
            .data( "ui-autocomplete" )._renderItem = function( ul, item ) {
               return $( "<li>" )
               .append( "<a>" + item.label + " - Rs:" + item.value + "</a>" )
               .appendTo( ul );
            };
	 });
	 
	 
	$(document).on('click', '.add_row', function(){
		 var totalrow = parseInt($('#totalrow').val());
		 
		if(totalrow > 0) {
			if(!emptystr($('#productcode_'+totalrow).val()) && !emptystr($('#productprice_'+totalrow).val()) && !emptystr($('#productquantity_'+totalrow).val()) && !emptystr($('#totalprice_'+totalrow).val())){
				 
				totalrowinc = totalrow + 1;
				$('#totalrow').val(totalrowinc);			 
				
				//getting row html
				$('#billingbody').append(returnhtmlrow(totalrowinc));
			 
				//update price
				calculateprice();
			 
			} else {
				//alert('Fill all fields for next row');
			}
		} else {
			//getting row html
			$('#billingbody').append(returnhtmlrow(1));
			$('#totalrow').val(1);
		}
	 });
	 
	$(document).on('click', '.remove_row', function(){
          var row_id = $(this).attr("id");
		  var res = row_id.split("_");
          $('#rowid_'+res[1]).remove();
		  		  
		  //update price
		  calculateprice();
		  
		  emptyrowcheck();
     });
	 
	 
	 var emptyrowcheck = function(){
							 var totalrow = parseInt($('#totalrow').val());
							 var rowavailable = 0;
								 
								 
							 for (i = 1; i <= totalrow; i++) { 
								if($('#rowid_'+i).length) {
									rowavailable = 1;
									break;
								}
							}
							
							if(rowavailable == 0) {
								$('#totalrow').val(0);
								$('.add_row').click();
							}
						}
						
						
	var returnhtmlrow = function(totalrowinc){
						var addhtml = '<tr id="rowid_'+totalrowinc+'">';
							addhtml += '<td>';
							addhtml += '<input class="productautosearch" type="text" name="productname[]" id="productname_'+totalrowinc+'" value="">';
							addhtml += '<input type="hidden" name="productcode[]" id="productcode_'+totalrowinc+'" value="">';
							addhtml += '</td>';
							addhtml += '<td id="billname_'+totalrowinc+'">-</td>';
							addhtml += '<td>';
							addhtml += '<strong id="price_txt_'+totalrowinc+'">0.00</strong>';
							addhtml += '<input type="hidden" name="productprice[]" id="productprice_'+totalrowinc+'" value="0">';
							addhtml += '</td>';
							addhtml += '<td>';
							addhtml += '<input  class="productquantityser billinput"  maxlength="2" type="text"  onkeypress="return Isnumber(event);" name="productquantity[]" id="productquantity_'+totalrowinc+'" value="1" style="width:50%">';
							addhtml += '</td>';
							addhtml += '<td>';
							addhtml += '<strong id="ttprice_txt_'+totalrowinc+'">0.00</strong>';
							addhtml += '<input type="hidden" name="totalprice[]" id="totalprice_'+totalrowinc+'" value="0"> ';
							addhtml += '</td>';
							addhtml += '<td>';
							addhtml += '<button class="btn btn-xs btn-danger remove_row" id="remove_'+totalrowinc+'">';
							addhtml += '<i class="ace-icon fa fa-remove bigger-120"></i>';
							addhtml += '</button>';
							addhtml += '</td>';
							addhtml += '</tr>';
							
							return addhtml;
						}
						
	 var calculateprice = function(){
								 var totalrow = parseInt($('#totalrow').val());
								 var totallprice = sgst = cgst = payable = 0;
								 
								 
								 for (i = 1; i <= totalrow; i++) { 
									if($('#rowid_'+i).length) {
										totallprice = parseFloat(totallprice) + parseFloat($('#totalprice_'+i).val());
									}
								}
								
								if(parseFloat(totallprice) > 0) {
									sgst = (parseFloat(totallprice) / 100) * 2.5;
									cgst = (parseFloat(totallprice) / 100) * 2.5;
									payable = parseFloat(totallprice) + parseFloat(sgst) +parseFloat(cgst);
									
									$('#allprice_txt').html(totallprice.toFixed(2));
									$('#sgst_txt').html(sgst.toFixed(2));
									$('#cgst_txt').html(cgst.toFixed(2));
									$('#payable_txt').html(payable.toFixed(2));
									
									$('#allprice').val(totallprice.toFixed(2));
									$('#sgst').val(sgst.toFixed(2));
									$('#cgst').val(cgst.toFixed(2));
									$('#payable').val(payable.toFixed(2));
									
								} else {
									$('#allprice_txt').html('0.00');
									$('#sgst_txt').html('0.00');
									$('#cgst_txt').html('0.00');
									$('#payable_txt').html('0.00');
									
									$('#allprice').val('0.00');
									$('#sgst').val('0.00');
									$('#cgst').val('0.00');
									$('#payable').val('0.00');
								}
							}	
							
							
	var savebill = function() {
						var totalrow = parseInt($('#totalrow').val());
						var totallprice = sgst = cgst = payable = 0;
						var allok = returnval = 1;
						var billitems = {};
						for (i = 1; i <= totalrow; i++) { 
							if($('#rowid_'+i).length) {
								if(!emptystr($('#productcode_'+i).val()) && !emptystr($('#productprice_'+i).val())) {
									
									if(emptystr($('#productquantity_'+i).val()) || emptystr($('#totalprice_'+i).val())) {
										allok = 0;																			
										break;
									} else {									
										//Total price
										totallprice = parseFloat(totallprice) + parseFloat($('#totalprice_'+i).val());
										
										//Bill items
										var bitems = {};
										bitems['code'] = $('#productcode_'+i).val();
										bitems['productprice'] = $('#productprice_'+i).val();
										bitems['productquantity'] = $('#productquantity_'+i).val();
										bitems['totalprice'] = $('#totalprice_'+i).val();
										billitems[$('#productcode_'+i).val()] = bitems;
									}
								} 							
							}
						}
						
						if(parseFloat(totallprice) > 0 && allok == 1) {
							sgst = (parseFloat(totallprice) / 100) * 2.5;
							cgst = (parseFloat(totallprice) / 100) * 2.5;
							payable = parseFloat(totallprice) + parseFloat(sgst) +parseFloat(cgst);
							
							//alert(totallprice+'   '+sgst+'   '+cgst+'   '+payable+'   '+JSON.stringify(billitems));
							
							var formData = new FormData();		
							 formData.append('billitems', JSON.stringify(billitems));
							 formData.append('totallprice', totallprice.toFixed(2));
							 formData.append('sgst', sgst.toFixed(2));
							 formData.append('cgst', cgst.toFixed(2));
							 formData.append('payable', payable.toFixed(2));
							 $.ajax({
									url: 'billing/new',
									type: 'POST',
									data: formData,
									async: true,
									processData: false,
									contentType: false,
									beforeSend: function() {
										$('#fullloading').show();
									},
									success: function(resdata){
										var response =  JSON.parse(resdata);
										if(typeof response =='object') {
											if(response.code == 200){
												//alert(response.billnumber+'  -- '+response.printdate+'  -- '+response.printtext+'  -- '+response.totalprice+'  -- '+response.sgst+'  -- '+response.cgst+'  -- '+response.payable+'  -- ')
												printdata(response);
												
												//alert('Bill generated');
												$('#billingbody').html('');
												emptyrowcheck();
												calculateprice();
												$('#productname_1').focus();
											} else {
												alert('Error in bill generate. Kindly Contact Owner or techinical person');
											}											
										} else {
											alert('Error in bill generate. Kindly Contact Owner or techinical person');
										}
										$('#fullloading').hide();
									},
									error: function(){
										alert('Error in bill generate. Kindly Contact Owner or techinical person');	
										$('#fullloading').hide();
									}                                                                     
								});
							
						} else {
							alert('Product/quantity is missing. Check the bill.');
						}
					}
					
					
	var printdata = function(billresponse) {
						
						var formData = new FormData();		
							 formData.append('billnumber', billresponse.billnumber);
							 formData.append('printdate', billresponse.printdate);
							 formData.append('printtext', billresponse.printtext);
							 formData.append('totalprice', billresponse.totalprice);
							 formData.append('sgst', billresponse.sgst);
							 formData.append('cgst', billresponse.cgst);
							 formData.append('payable', billresponse.payable);
						 $.ajax({
								url: 'http://localhost:8080/print/example/interface/windows-usb.php',
								type: 'POST',
								data: formData,
								async: true,
								processData: false,
								contentType: false,
								beforeSend: function() {
									$('#fullloading').show();
								},
								success: function(resdata){
									$('#fullloading').hide();
								},
								error: function(){
									//alert('Error in bill generate. Kindly Contact Owner or techinical person');	
									$('#fullloading').hide();
								}                                                                     
							});
					}
					
					
	
	var emptystr = function(mixed_var) {
			var key;
			if (mixed_var === "" || mixed_var === 0 || mixed_var === 0.00 || mixed_var === "0" || mixed_var === null || mixed_var === false || mixed_var === undefined ) {
				return true;
			}
			if (typeof mixed_var == 'object') {
				for (key in mixed_var) {
					return false;
				}
				return true;
			}
			
			return false;
		}
				
				
				