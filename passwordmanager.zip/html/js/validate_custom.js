$(document).ready(function(){
	$("#loginform").validate({
		rules:{
			useremail   	:	{ required:true },
			password   		:	{ required:true },
			 },
		messages:{
			useremail   	:	{ required:'Usermame is required' },
			password   		:	{ required:'Password is required' },
		},
		submitHandler: function (form) {
			$('#fullloading').show();
			form.submit();
		}
	});
	$("#registerform").validate({
		rules:{
			fullname   	:	{ required:true },
			email   		:	{ required:true, email:true },
			mobile   		:	{ required:true },
			userName   		:	{ required:true, minlength : 6 },
			userPassword   	:	{ required:true, minlength : 6  },
			lockpin   		:	{ required:true, minlength : 4  },
			 },
		messages:{
			fullname   	:	{ required:'Fullname is required' },
			email   		:	{ required:'Email is required', email:'Invalid email address' },
			mobile   		:	{ required:'Mobile is required' },
			userName   		:	{ required:'Username is required', minlength : "Username must be greater then 6 digits"  },
			userPassword   	:	{ required:'Password is required', minlength : "Password must be greater then 6 digits"  },
			lockpin   		:	{ required:'Lock PIN is required', minlength : "Lock PIN must be 4 digits"  },
		},
		submitHandler: function (form) {
			$('#fullloading').show();
			form.submit();
		}
	});
	
	$("#websitesform").validate({
		rules:{
			websitename   	:	{ required:true },
			websiteurl   		:	{ required:true },
			 },
		messages:{
			websitename   	:	{ required:'Website name is required' },
			websiteurl   		:	{ required:'Website URL is required' },
		},
		submitHandler: function (form) {
			$('#fullloading').show();
			form.submit();
		}
	});
});

