<?php

class WebsitesController extends Zend_Controller_Action
{
	protected $_redirector = null;
	protected $_dbAdapter = null;
    
	public function init()
    {
		$registry = Zend_Registry::getInstance();
		$this->_dbAdapter = $registry->dbAdapter;
        $this->_redirector = $this->_helper->getHelper('Redirector');

        $this->_user = Default_Models_AdminAuth::getIdentity();
	    if($this->_user->userId)
        {
			$userType = $this->_user->userType;			
			if($userType != 'A') {					
				$this->_redirector->gotoSimple('index','dashboard','admin');
				exit;
			}
		} else {
			$this->_redirector->gotoSimple('index','auth','admin');
		}
	}

    public function indexAction()
    {
		#Getting Request Info
		$request = $this->getRequest();
		$_GET = $request->getParams();
		$_POST = $request->getPost(); 
		
		#Getting Objects
		$commonobj = new Default_Models_Common();
		
		#POST Process
		$searchTerm = $where = '';
		
		if($this->getRequest()->isPost()) {
			/*$searchTerm = trim($_POST['searchTerm']);
			if(!empty($searchTerm))
			$where .= " AND (publishname LIKE '%".$searchTerm."%' ) ";*/
		}		
		
		#Getting Complaint list
		$where = "";
		$websites =  $commonobj->getWebsites($where);
		
		#Setting data to view page
		$this->view->websites = $websites;
		$this->view->searchTerm = $searchTerm;
		$this->view->msg = str_replace('_', ' ', $_GET['msg']);;		
    }
	
    public function usersAction()
    {
		#Getting Request Info
		$request = $this->getRequest();
		$_GET = $request->getParams();
		$_POST = $request->getPost(); 
		
		#Getting Objects
		$commonobj = new Default_Models_Common();
		
		#POST Process
		$searchTerm = $where = '';
		
		if($this->getRequest()->isPost()) {
			/*$searchTerm = trim($_POST['searchTerm']);
			if(!empty($searchTerm))
			$where .= " AND (publishname LIKE '%".$searchTerm."%' ) ";*/
		}		
		
		#Getting Complaint list
		$where = "";
		$allpeoples =  $commonobj->getAllPeoples($where);
		
		#Setting data to view page
		$this->view->allpeoples = $allpeoples;
		$this->view->searchTerm = $searchTerm;
		$this->view->msg = str_replace('_', ' ', $_GET['msg']);;		
    }

    public function newAction()
    {	
		#Getting Request Info
		$request = $this->getRequest();
		$_GET = $request->getParams();
		$_POST = $request->getPost();
		
		#Getting Objects
		$commonobj = new Default_Models_Common();
		
		#variables
		$errormsg = '';
		$info = array();
		
		#POST Process
		if($this->getRequest()->isPost()) {	
			$info = $_POST;
			$where = " AND websiteurl = '".$info['websiteurl']."' ";
			$websites =  $commonobj->getWebsites($where);
			if($websites) {
				$errormsg = "Website URL already exist";
			} else {
				if($commonobj->insertWebsites($info)) {
					$this->_redirector->gotoSimple('index','websites','admin',  array('msg' => 'Added_successfully'));
				} else {
					$errormsg = "Error in website create";
				}
			}
		}
		
		#Setting data to view page
		$this->view->profileaction = "add";
		$this->view->errormsg = $errormsg;
		$this->view->info = $info;
    }	
	
	public function editAction()
	{
		#Getting Request Info
		$request = $this->getRequest();
		$_GET = $request->getParams();
		$_POST = $request->getPost();
		
		#variables
		$errormsg = '';		
		
		#Getting Objects
		$commonobj = new Default_Models_Common();
		
		#Getting Complaint info
		$where = " and webid = ".$_GET['rowid']."";
		$info =  $commonobj->getWebsites($where);
		
		if(empty($info)){
			$errormsg = "Invaild Website Id";
		} else {
			$info = $info[0];
		}
		
		#POST Process
		if($this->getRequest()->isPost() && !empty($info)) {			
			if(empty($errormsg)) {
				$where = " AND websiteurl = '".$_POST['websiteurl']."' AND webid != '".$_POST['webid']."' ";
				$websites =  $commonobj->getWebsites($where);
				if($websites) {
					$errormsg = "Website URL already exist";
				} else {
					$commonobj->updateWebsites($_POST);
					$this->_redirector->gotoSimple('index','websites','admin',  array('msg' => 'Updated_successfully'));
				}
			}
		}
		
		#data to view page
		$this->view->info = $info;	
		$this->view->profileaction = "edit";
		$this->view->errormsg = $errormsg;
	}
}
