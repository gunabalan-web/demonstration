<?php
class AuthController extends Zend_Controller_Action 
{
	protected $_redirector = null;
    
	public function init()
    {
        $this->_redirector = $this->_helper->getHelper('Redirector');
		$this->_user = Default_Models_AdminAuth::getIdentity();
	    if($this->_user->userId)
        {
			$userType = $this->_user->userType;			
			if($userType == 'A')							
				$this->_redirector->gotoSimple('index','websites','admin');
			else
				$this->_redirector->gotoSimple('index','dashboard','admin');
			exit;
		}
	}

    public function indexAction() 
    {
		$request = $this->getRequest();
		$_GET = $request->getParams();
		$_POST = $request->getPost(); 
		
		$this->view->pageTitle = "Administrator Login"; 
		
		$form  = new Default_Form_Auth();
		if ($request->isPost()) {
			if ($form->isValid($_POST)) {
				$auth = new Default_Models_AdminAuth($_POST["useremail"],$_POST["password"]);
				if ($auth->authenticate()) {
					$this->_user = Default_Models_AdminAuth::getIdentity();
					if($this->_user->userId)
					{
						$userType = $this->_user->userType;	
						if($userType == 'A')							
							$this->_redirector->gotoSimple('index','websites','admin');
						else
							$this->_redirector->gotoSimple('index','dashboard','admin');
					}
					exit;
				} else {
					$this->view->errormessage = "invalid login";
				}
		}
		}
		$this->view->succmsg = isset($_GET['msg']) ? $_GET['msg'] : '';
        $this->view->form = $form;
	}
}	
