<?php

class DashboardController extends Zend_Controller_Action
{
	protected $_redirector = null;
	protected $_dbAdapter = null;
    
	public function init()
    {
		$registry = Zend_Registry::getInstance();
		$this->_dbAdapter = $registry->dbAdapter;
        $this->_redirector = $this->_helper->getHelper('Redirector');

        $this->_user = Default_Models_AdminAuth::getIdentity();
	    if($this->_user->userId)
        {
			$userType = $this->_user->userType;			
			if($userType == 'A') {
				$this->_redirector->gotoSimple('index','websites','admin');
				exit;
			}
		} else {
			$this->_redirector->gotoSimple('index','auth','admin');
				exit;
		}
	}

    public function indexAction()
    {
		#Getting Request Info
		$request = $this->getRequest();
		$_GET = $request->getParams();
		$_POST = $request->getPost(); 
		
		#Getting Objects
		$commonobj = new Default_Models_Common();
		
		#POST Process
		$searchTerm = $where = '';
		
		if($this->getRequest()->isPost()) {
			/*$searchTerm = trim($_POST['searchTerm']);
			if(!empty($searchTerm))
			$where .= " AND (publishname LIKE '%".$searchTerm."%' ) ";*/
		}		
		
		#Getting Complaint list
		$where = "";
		$websites =  $commonobj->getWebsites($where);
		
		$userinfo = Default_Models_AdminAuth::getIdentity();
		
		#Setting data to view page
		$this->view->websites = $websites;
		$this->view->searchTerm = $searchTerm;
		$this->view->userinfo = $userinfo;
		$this->view->msg = str_replace('_', ' ', $_GET['msg']);		
    }
	
	public function loginsAction() 
    {
		$request = $this->getRequest();
		$_GET = $request->getParams();
		$_POST = $request->getPost(); 
		
		#Getting Objects
		$commonobj = new Default_Models_Common();
		
		$success = 0;
		$postinfo = $siteusers = array();
		$where = " AND webid = '".$_GET['webid']."'";
		$websites =  $commonobj->getWebsites($where);		
		
		$form  = new Default_Form_Auth();
		if ($request->isPost()) {
			$postinfo = $_POST;
			if ($form->isValid($_POST)) {
				$success = 1;
			}
		}
		
		if(isset($_GET['succ']))
			$success = 1;
		
		
		$this->_user = Default_Models_AdminAuth::getIdentity();
	    if($this->_user->userId) {
			$where = " AND ss.userid = '".$this->_user->userId."' AND ss.webid = '".$_GET['webid']."'";
			$siteusers = $commonobj->getSiteUser($where); 
			
			$where = " AND a.userId = '".$this->_user->userId."' "; 
			$customerinfo = $commonobj->getAllPeoples($where);
		}
		
        $this->view->postinfo = $postinfo;
        $this->view->form = $form;
        $this->view->successstatus = $success;
        $this->view->siteusers = $siteusers;
        $this->view->customerinfo = $customerinfo[0];
        $this->view->websites = (isset($websites[0])) ? $websites[0] : '';
	}
	
	public function sendsmsAction() 
    {
		$request = $this->getRequest();
		$_GET = $request->getParams();
		$_POST = $request->getPost(); 
		
		#Getting Objects
		$commonobj = new Default_Models_Common();
		$verifycode = '';
		
		$this->_user = Default_Models_AdminAuth::getIdentity();
	    if($this->_user->userId) {
			$where = " AND a.userId = '".$this->_user->userId."' "; 
			$customerinfo = $commonobj->getAllPeoples($where);
			if(isset($customerinfo[0])) {
				#Post process
				if ($request->isPost()) {
					$postinfo = $_POST;
					$verifycode = rand(11111,99999);
					
					$smsarr[] = array(
									"mobile" => $customerinfo[0]->mobile,
									"message" => "Clould Password Manager : verify your number using code ".$verifycode.'.',
								);					
					$commonobj->sendtestsms($smsarr);
					echo json_encode(array("code" => '200', "msg" => 'SMS Sent', 'verifycode' => $verifycode));
					exit;
				}
			} else {
				echo json_encode(array("code" => '500', "msg" => 'Send SMS error', 'verifycode' => $verifycode));
				exit;
			}
		}
		echo json_encode(array("code" => '500', "msg" => 'Send SMS error', 'verifycode' => $verifycode));
		exit;
	}
	
	public function sendemailAction() 
    {
		$request = $this->getRequest();
		$_GET = $request->getParams();
		$_POST = $request->getPost(); 
		
		#Getting Objects
		$commonobj = new Default_Models_Common();
		$verifycode = '';
		
		$this->_user = Default_Models_AdminAuth::getIdentity();
	    if($this->_user->userId) {
			$where = " AND a.userId = '".$this->_user->userId."' "; 
			$customerinfo = $commonobj->getAllPeoples($where);
			if(isset($customerinfo[0])) {
				#Post process
				if ($request->isPost()) {
					$postinfo = $_POST;
					$verifycode = rand(11111,99999);
					
					$emailinfo = array(
							"fromemail" => $this->view->testemail,
							"fromname" => 'Admin',
							"toemail" => $customerinfo[0]->emailAddress,
							"subject" =>"Clould Password Manager : Email Verification",
							"texthtml" =>"Dear <strong>".$customerinfo[0]->firstName."</strong>,<br><br>
							Verify your email using below OPT code.
								<strong>OPT :</strong> ".$verifycode."<br>
								Regards,<br>
								<strong>Clould Password Manager</strong>",
						);
					$output = $commonobj->sendtestemail($emailinfo);
					echo json_encode(array("code" => '200', "msg" => 'Email Sent', 'verifycode' => $verifycode));
					exit;
				}
			} else {
				echo json_encode(array("code" => '500', "msg" => 'Send Email error', 'verifycode' => $verifycode));
				exit;
			}
		}
		echo json_encode(array("code" => '500', "msg" => 'Send Email error', 'verifycode' => $verifycode));
		exit;
	}
	
	public function saveusernameAction() 
    {
		$request = $this->getRequest();
		$_GET = $request->getParams();
		$_POST = $request->getPost(); 
		
		#Getting Objects
		$commonobj = new Default_Models_Common();
		
		$this->_user = Default_Models_AdminAuth::getIdentity();
	    if($this->_user->userId) {
			#Post process
			if ($request->isPost()) {
				$postinfo = $_POST;
				$postinfo['userid'] = $this->_user->userId;
				
				$where = " AND ss.userid = '".$this->_user->userId."' AND ss.webid = '".$postinfo['webid']."' AND ss.username LIKE '".$postinfo['username']."' ";				
				$siteuser = $commonobj->getSiteUser($where);
				if(!isset($siteuser[0])) {
					$commonobj->insertSiteUser($postinfo);
				}
				echo json_encode(array("code" => '200', "msg" => 'Your login details saved'));
				exit;
			}
			
		}
		echo json_encode(array("code" => '500', "msg" => 'Save Email error'));
		exit;
	}
	
	public function checkusernameAction() 
    {
		$request = $this->getRequest();
		$_GET = $request->getParams();
		$_POST = $request->getPost(); 
		
		#Getting Objects
		$commonobj = new Default_Models_Common();
		
		$this->_user = Default_Models_AdminAuth::getIdentity();
	    if($this->_user->userId) {
			#Post process
			if ($request->isPost()) {
				$postinfo = $_POST;
				$postinfo['userid'] = $this->_user->userId;
				
				$where = " AND ss.userid = '".$this->_user->userId."' AND ss.webid = '".$postinfo['webid']."' AND ss.username LIKE '".$postinfo['username']."' ";				
				$siteuser = $commonobj->getSiteUser($where);
				if(!isset($siteuser[0])) {
					echo json_encode(array("code" => '200', "msg" => 'Your login details saved', 'show' => 1));
					exit;
				}
				echo json_encode(array("code" => '500', "msg" => 'Your login details saved', 'show' => 0));
				exit;
			}
			
		}
		echo json_encode(array("code" => '500', "msg" => 'Save Email error', 'show' => 0));
		exit;
	}
	
	public function allsavedpasswordAction() 
    {
		$request = $this->getRequest();
		$_GET = $request->getParams();
		$_POST = $request->getPost(); 
		
		#Getting Objects
		$commonobj = new Default_Models_Common();
		
		$this->_user = Default_Models_AdminAuth::getIdentity();
	    if($this->_user->userId) {
			$where = " AND ss.userid = '".$this->_user->userId."' ";
			
			if($this->getRequest()->isPost()) {
				$searchTerm = trim($_POST['searchTerm']);
				if(!empty($searchTerm))
				$where .= " AND (w.websitename LIKE '%".$searchTerm."%' OR ss.username LIKE '%".$searchTerm."%'  )";
			}	
			
			$siteusers = $commonobj->getSiteUser($where);
		}
		$this->view->siteusers = $siteusers;
	}
	
	public function profileAction() 
    {
		$request = $this->getRequest();
		$_GET = $request->getParams();
		$_POST = $request->getPost(); 
		
		#Getting Objects
		$commonobj = new Default_Models_Common();
		
		$this->_user = Default_Models_AdminAuth::getIdentity();
	    if($this->_user->userId) {
			$where = " AND a.userId = '".$this->_user->userId."' "; 
			$customerinfo = $commonobj->getAllPeoples($where);
			
		}
		$this->view->customerinfo = $customerinfo[0];
	}
		
}
