<?php

class PeoplesController extends Zend_Controller_Action
{
	protected $_redirector = null;
	protected $_dbAdapter = null;
    
	public function init()
    {
		$registry = Zend_Registry::getInstance();
		$this->_dbAdapter = $registry->dbAdapter;
        $this->_redirector = $this->_helper->getHelper('Redirector');   
		
	}

    public function indexAction()
    {		
		#Getting Request Info
		$request = $this->getRequest();
		$_GET = $request->getParams();
		$_POST = $request->getPost();
		
		#Getting Objects
		$commonobj = new Default_Models_Common();
		
		$identity = $this->view->adminidentity;
		$userType = $identity->userType;
		if($identity) {								
			$this->_redirector->gotoSimple('index','websites','admin');
			exit;
		}
		
		#variables
		$errormsg = '';
		$info = array();
		
		#POST Process
		if($this->getRequest()->isPost()) {	
			$info = $_POST;
			
			$where = " AND a.userName LIKE '".$_POST['userName']."'";
			$infoexist = $commonobj->getAllPeoples($where);
			if(empty($infoexist)) {
				$commonobj->insertPeoples($info);
				$this->_redirector->gotoSimple('index','auth','admin',  array('msg' => '1'));
			} else {
				$errormsg = "Username already exist";
			}
		}
		
		#Setting data to view page
		$this->view->profileaction = "Register";
		$this->view->errormsg = $errormsg;
		$this->view->info = $info;
    }
}